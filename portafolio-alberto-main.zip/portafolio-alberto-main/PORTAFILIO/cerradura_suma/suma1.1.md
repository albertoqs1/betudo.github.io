#desarrollo de la propiedad de lacerradura con suma
print("cerradura: la suma de dos numeros reales da como resultado otro numero real.")
print("a + b pertenece R")
print() 

#imprime el mensaje que indica que el programa demostrara la propiedad de la cerradura
print("El siguiente programa realiza la propiedad de la cerradura.")
print()

num1 = int(input("ingrese el primer numero: "))
num2 = int(input("ingrese el segundo numero: "))

#calcular suma
suma = num1 + num2
print(suma)
#mostra resultado

