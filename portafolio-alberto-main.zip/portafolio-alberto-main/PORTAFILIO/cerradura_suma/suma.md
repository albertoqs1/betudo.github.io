print("2 numeros a sumar")
print("")
suma=5+9
print(suma)