
#imprime el mensaje que indica que el programa demostrara la propiedad de la cerradura
print("El siguiente programa realiza la propiedad de la cerradura.")
print()

num1 = float(input("ingrese el primer numero: "))
num2 = float(input("ingrese el segundo numero: "))

#calcular suma
mult = num1 * num2

#mostra resultado
print("la multi de {} y {} es: ".format(num1, num2), mult)