#desarrollo de la propiedad de lacerradura con suma
print("cerradura: la suma de dos numeros reales da como resultado otro numero real.")
print("a + b pertenece R")
print() #linea en blanco 

#imprime el mensaje que indica que el programa demostrara la propiedad de la cerradura
print("El siguiente programa realiza la propiedad de la cerradura.")
print()

num1 = float(input("ingrese el primer numero: "))
num2 = float(input("ingrese el segundo numero: "))

#calcular suma
suma = num1 + num2

#mostra resultado
print("la suma de{} y {} es: ".format(num1, num2), suma)